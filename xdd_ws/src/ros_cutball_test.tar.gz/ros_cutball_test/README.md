# ros_cutball

Using ROS and ZED to implement the UAV viewing whether a balloon is falling.
